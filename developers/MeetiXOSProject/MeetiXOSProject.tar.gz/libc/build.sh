#!/bin/sh
. ../MXbase.sh

TARGET=$1

with TARGET					"all"
with SRC					"src"
with OBJ					"obj"
with INC					"inc"
with INC_API				"../libapi/inc"
with INC_KERNEL				"/home/marco/Scrivania/MeetiX-OS/EvangelionNG/inc"

with ARTIFACT_NAME			"libc.a"
ARTIFACT_LOCAL="$ARTIFACT_NAME"
ARTIFACT_TARGET="$SYSROOT_LIB/$ARTIFACT_NAME"

with CFLAGS					"-std=c++11 -I$INC -I$INC_API -I$INC_KERNEL -I$SRC/musl -fext-numeric-literals -Wno-narrowing"
with CCFLAGS				"-std=c11 -I$INC -I$INC_API -I$INC_KERNEL"

with CRT_SRC				"crt"
with CRT_OBJ				"crtobj"
CRT_NAMES=("crt0" "crti" "crtn")

CONFORMITY_CHECK="$SRC/_conformity.c"


# always create output folder
mkdir -p $OBJ
mkdir -p $CRT_OBJ

##
#	clean object directory
##
function targetClean() 
{
	echo "cleaning:"
	rm $ARTIFACT_LOCAL
	
	cleanDirectory $OBJ
	cleanDirectory $CRT_OBJ
	
	changes --clear
}

##
#	compile conformity
##
function targetCheckC++Conformity() 
{
	# this checks the C conformity by compiling it with the non-C++ compiler
	echo "checking if headers are C++11 conform:"
	out=`sourceToObject $CONFORMITY_CHECK`
	list $out
	i686-mx-gcc -c $CONFORMITY_CHECK -o "$OBJ/$out" $CCFLAGS
	failOnError
}

##
#	compile all source that it find
##
function targetCompile() 
{
	echo "compiling:"
	
	# check if headers have changed
	headersHaveChanged=1
	for file in $(find "$INC" -iname "*.h"); do
		changes -c $file
		if [ $? -eq 1 ]; then
			headersHaveChanged=1
		fi
		changes -s $file
	done
	
	# compile sources
	for file in $(find "$SRC" -iname "*.cpp" -o -iname "*.c"); do
		
		if [ $file == "src/_conformity.c" ]; then
			echo "   (skipping _conformity.c)"
			continue
		fi
		 
		changes -c $file
		changed=$?
		if ( [ $headersHaveChanged -eq 1 ] || [ $changed -eq 1 ] ); then
			out=`sourceToObject $file`
			list $out
			i686-mx-g++ -c $file -o "$OBJ/$out" $CFLAGS
			failOnError
			changes -s $file
		fi
	done

	
	# assemble sources
	for file in $(find "$SRC" -iname "*.s"); do
		
		changes -c $file
		changed=$?
		if ( [ $headersHaveChanged -eq 1 ] || [ $changed -eq 1 ] ); then
			out=`sourceToObject $file`
			list $out
			i686-mx-as -s $file -o "$OBJ/$out"
			failOnError
			changes -s $file
		fi
	done
}

##
#	compile the crts
##
function targetAssembleCrts() 
{
	echo "assembling CRTs:"
	for name in ${CRT_NAMES[@]}; do
		list $name
		i686-mx-as $CRT_SRC/$name.S -o "$CRT_OBJ/$name.o"
		failOnError
	done
}

##
#	create lib archive
##
function targetArchive() 
{
	echo "archiving:"
	i686-mx-ar -r $ARTIFACT_LOCAL $OBJ/*.o
}

##
#	install to dir the headers
##
function targetInstallHeaders() 
{
	echo "creating header installation directory"
	mkdir -p $SYSROOT_INCLUDE
	
	echo "installing headers"
	cp -r $INC/* $SYSROOT_INCLUDE/
	
}

##
#	install to dir all
##
function targetInstall() 
{
	targetInstallHeaders
	
	echo "creating lib installation directory"
	mkdir -p $SYSROOT_LIB
	
	echo "installing artifact"
	cp $ARTIFACT_LOCAL $ARTIFACT_TARGET
	
	echo "installing crts"
	for name in ${CRT_NAMES[@]}; do
		list $name
		cp $CRT_OBJ/$name.o $SYSROOT_LIB/$name.o
	done
	
	echo "installing empty libm"
	i686-mx-ar -r $SYSROOT_LIB/libm.a
	
	# c'mon
	chmod -R 0777 $SYSROOT
}

# show chosed target
targetHeadline "target: $TARGET"

# execute targets
if [[ $TARGET == "install-headers" ]]; then
	targetInstallHeaders
	
elif [[ $TARGET == "all" ]]; then
	targetCheckC++Conformity
	targetCompile
	targetAssembleCrts
	targetArchive
	targetInstall
	
elif [[ $TARGET == "clean" ]]; then
	targetClean
	
else
	echo "unknown target: '$TARGET'"
	exit 1
fi

exit 0
