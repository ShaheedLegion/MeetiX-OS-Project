#include <math.h>

int finite(double x)
{
	return isfinite(x);
}
