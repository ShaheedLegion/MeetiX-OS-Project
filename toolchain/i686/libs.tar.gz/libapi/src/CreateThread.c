/*********************************************************************************
* MeetiX OS By MeetiX OS Project [Marco Cicognani]                               *
* 																			     *
* This program is free software; you can redistribute it and/or                  *
* modify it under the terms of the GNU General Public License                    *
* as published by the Free Software Foundation; either version 2				 *
* of the License, or (char *argumentat your option) any later version.			 *
*																				 *
* This program is distributed in the hope that it will be useful,				 *
* but WITHout ANY WARRANTY; without even the implied warranty of                 *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 				 *
* GNU General Public License for more details.									 *
*																				 *
* You should have received a copy of the GNU General Public License				 *
* along with this program; if not, write to the Free Software                    *
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA *
**********************************************************************************/

#include "eva/user.h"
#include "__internal.h"

/**
 * Thread setup routine, used by the thread creation call. Assumes that the created thread
 * has a valid "userEntry" - otherwise exits with error code -1.
 */
void ThreadSetupRoutine()
{
	SyscallGetThreadEntry data;
	syscall(SYSCALL_GET_THREAD_ENTRY, (uint32_t) &data);

	void (*userEntry)(void*) = (void(*)(void*)) (data.userEntry);

	if (userEntry)
	{
		// Call the entry
		userEntry(data.userData);

		return __ExitThread();
	}

	return __ExitThread();
}

// redirect
Tid CreateThread(void *function)
{
	return CreateThreadD(function, NULL);
}

// redirect
Tid CreateThreadD(void *function, void *data)
{
	return CreateThreadDNS(function, data, NULL, NULL);
}

// redirect
Tid CreateThreadN(void *function, const char *name)
{
	return CreateThreadDNS(function, NULL, name, NULL);
}

// redirectz
Tid CreateThreadDN(void *function, void *data, const char *name)
{
	return CreateThreadDNS(function, data, name, NULL);
}

// redirect
Tid CreateThreadDS(void *function, void *data, CreateThreadStatus *outStatus)
{
	return CreateThreadDNS(function, data, NULL, outStatus);
}

/**
 * create an asincronous thread
 */
Tid CreateThreadDNS(void *function, void *data, const char *name, CreateThreadStatus *outStatus)
{
	SyscallCreateThread callData;
	callData.initialEntry = (void*) ThreadSetupRoutine;
	callData.userEntry = function;
	callData.userData = data;
	callData.threadName = (char*) name;

	syscall(SYSCALL_CREATE_THREAD, (uint32_t) &callData);

	if (outStatus) *outStatus = callData.status;
	return callData.threadID;
}
