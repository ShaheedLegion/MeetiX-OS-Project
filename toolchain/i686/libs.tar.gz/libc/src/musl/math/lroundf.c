#include <math.h>

long lroundf(float x)
{
	return roundf(x);
}
