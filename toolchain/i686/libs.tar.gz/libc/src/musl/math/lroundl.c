#include <math.h>

long lroundl(long double x)
{
	return roundl(x);
}
