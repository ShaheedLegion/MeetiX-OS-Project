/*********************************************************************************
* MeetiX OS By MeetiX OS Project [Marco Cicognani & D. Morandi]                  *
* 																			     *
* This program is free software; you can redistribute it and/or                  *
* modify it under the terms of the GNU General Public License                    *
* as published by the Free Software Foundation; either version 2				 *
* of the License, or (char *argumentat your option) any later version.			 *
*																				 *
* This program is distributed in the hope that it will be useful,				 *
* but WITHout ANY WARRANTY; without even the implied warranty of                 *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 				 *
* GNU General Public License for more details.									 *
*																				 *
* You should have received a copy of the GNU General Public License				 *
* along with this program; if not, write to the Free Software                    *
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA *
**********************************************************************************/

#include <eva.h>
#include "stdlib.h"
#include "stdio.h"
#include "string.h"

/**
 *
 */
int setenv(const char *key, const char *val, int overwrite)
{
	// declare arguments
	const int cmdlen = strlen("--setenv ");
	const int keylen = strlen(key);
	const int eqlen = strlen("=");
	const int valen = strlen(val);
	char arg[cmdlen + keylen + eqlen + valen];

	// create the arguments
	memcpy(arg, "--setenv ", cmdlen);
	strcat(arg, key);
	strcat(arg, "=");
	strcat(arg, val);

	// exec shell and check status
	if (Spawn("/cmd/mx", arg, "/", SECURITY_LEVEL_APPLICATION) == SPAWN_STATUS_SUCCESSFUL) return 0;

	return -1;
}
