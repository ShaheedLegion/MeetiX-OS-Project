#include "assert.h"
#include "ctype.h"
#include "errno.h"
#include "inttypes.h"
#include "malloc.h"
#include "stdint.h"
#include "stdlib.h"
#include "string.h"
#include "wchar.h"
#include <limits.h>

void __g_libc_test() {

}
